#ifndef SQUID_EUI_CONFIG_H
#define SQUID_EUI_CONFIG_H

namespace Eui
{

class EuiConfig
{
public:
    int euiLookup;
};

extern EuiConfig TheConfig;

} // namespace Eui

#endif /* SQUID_EUI_CONFIG_H */
